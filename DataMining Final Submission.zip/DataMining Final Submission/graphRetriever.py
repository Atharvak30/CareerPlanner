
import numpy as np
import networkx as nx
from typing import List, Dict, Tuple, Optional
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from sklearn.metrics.pairwise import cosine_similarity

"""
================================================================================
HYBRID GRAPH RETRIEVER - Summary
================================================================================

PURPOSE:
Retrieves relevant career information by combining semantic (text) and
structural (graph) similarity for GraphRAG queries.

INPUTS:
- knowledge_graph: NetworkX MultiDiGraph (175 nodes, 1558 edges)
- text_embeddings: 384-dim semantic vectors (SentenceTransformer)
- graph_embeddings: 128-dim structural vectors (Node2Vec)
- alpha: Weighting parameter
  * 0.0 = pure text (semantic only)
  * 1.0 = pure graph (structural only)
  * 0.5 = balanced
  * 0.6-0.8 = recommended (favors structure)

HYBRID FUSION:
Combines both embedding types using weighted concatenation:
  weighted_emb = concatenate([(1-α)·text_emb, α·graph_emb])

Example: α=0.6 → 40% semantic meaning, 60% structural patterns

RETRIEVAL PROCESS (4 Steps):
1. Find Matching Nodes - Exact/partial string match on query
2. Similarity Search - Cosine similarity on weighted embeddings (top-5)
3. Graph Relationships - Extract edges with lift/confidence scores
4. Important Neighbors - Add top-3 neighbors ranked by lift × confidence

OUTPUT:
List of LangChain Document objects with metadata:
- node_id: Node identifier
- source: 'query_match', 'similarity_search', 'graph_relationships', 'graph_neighbor'
- similarity: Cosine similarity score (if applicable)
- relationship: Edge type (if neighbor)
- importance: Lift × confidence score (if neighbor)

KEY METHODS:
- get_relevant_documents(query) - Main retrieval interface
- _find_matching_nodes() - String matching
- _find_similar_nodes() - Cosine similarity search
- _generate_node_text() - Format node data into readable text

USE CASE:
Powers GraphRAG by retrieving contextually relevant skills/jobs for
natural language career queries like:
"I want to be an ML engineer. What skills do I need?"
================================================================================
"""

class HybridGraphRetriever(BaseRetriever):
    """
    Custom retriever with adjustable text/graph embedding weighting.
    
    Args:
        alpha: Weight between text and graph embeddings
               - 0.0 = pure text (semantic only)
               - 1.0 = pure graph (structural only)
               - 0.5 = balanced (default)
    """
    class Config:
        arbitrary_types_allowed = True
        extra = "allow"  # Allow extra fields not defined in schema
    def __init__(
        self, 
        knowledge_graph: nx.MultiDiGraph,
        node_ids: List[str],
        text_embeddings: np.ndarray,           # (N, 384) matrix
        graph_embeddings: Dict[str, np.ndarray],  # {node_id: array(128,)}
        alpha: float = 0.5
    ):
        """Initialize retriever with weighted embedding fusion."""
        super().__init__()
        
        if not 0.0 <= alpha <= 1.0:
            raise ValueError(f"alpha must be between 0 and 1, got {alpha}")
        
        self.kg = knowledge_graph
        self.node_ids = node_ids
        self.text_embeddings = text_embeddings
        self.graph_embeddings = graph_embeddings
        self.alpha = alpha
        
        # Create weighted embeddings
        self.weighted_embeddings = self._create_weighted_embeddings()
        
        print(f"✓ Retriever created with {len(node_ids)} nodes")
        print(f"  Alpha (α) = {alpha}")
        print(f"  Text weight = {(1-alpha)*100:.0f}%, Graph weight = {alpha*100:.0f}%")
    

    def _create_weighted_embeddings(self) -> Dict[str, np.ndarray]:
        """Create weighted combination of text + graph embeddings."""
        weighted = {}
        
        # Iterate over node_ids and index into the array
        for i, node_id in enumerate(self.node_ids):
            text_emb = self.text_embeddings[i]  # Get row i from matrix
            
            if node_id in self.graph_embeddings:
                graph_emb = self.graph_embeddings[node_id]
                
                # Apply weights
                weighted_text = (1 - self.alpha) * text_emb
                weighted_graph = self.alpha * graph_emb
                
                # Concatenate
                combined = np.concatenate([weighted_text, weighted_graph])
            else:
                # No graph embedding, use text only
                combined = text_emb
            
            weighted[node_id] = combined
        
        print(f"  ✓ Created {len(weighted)} weighted embeddings")
        return weighted
    
    def _get_relevant_documents(self, query: str) -> List[Document]:
        """
        Main retrieval: combines matching + similarity + graph traversal.
        
        Args:
            query: User query (node name or partial match)
            
        Returns:
            List of Document objects
        """
        all_docs = []
        seen_nodes = set()
        
        print(f"\n Query: '{query}'")
        
        # Step 1: Find matching nodes
        matching_nodes = self._find_matching_nodes(query)
        
        if not matching_nodes:
            print(f"   ⚠️  No matches found")
            return []
        
        print(f"   ✓ Found {len(matching_nodes)} matching node(s): {matching_nodes[:3]}")
        
        # Step 2: Process each matching node (top 2)
        for query_node in matching_nodes[:2]:
            
            # 2a. Add the matched node
            if query_node in self.kg.nodes():
                node_data = self.kg.nodes[query_node]
                doc = Document(
                    page_content=self._generate_node_text(query_node, node_data),
                    metadata={
                        "node_id": query_node,
                        "node_type": node_data.get('node_type'),
                        "source": "query_match",
                        "alpha": self.alpha
                    }
                )
                all_docs.append(doc)
                seen_nodes.add(query_node)
            
            # 2b. Find similar nodes (using embeddings!)
            similar = self._find_similar_nodes(query_node, top_k=5)
            
            print(f"   ✓ Found {len(similar)} similar nodes")
            
            for node_id, similarity in similar:
                if node_id not in seen_nodes and node_id in self.kg.nodes():
                    node_data = self.kg.nodes[node_id]
                    doc = Document(
                        page_content=self._generate_node_text(node_id, node_data),
                        metadata={
                            "node_id": node_id,
                            "node_type": node_data.get('node_type'),
                            "source": "similarity_search",
                            "similarity": similarity,
                            "alpha": self.alpha
                        }
                    )
                    all_docs.append(doc)
                    seen_nodes.add(node_id)
            
            # 2c. Get graph relationships (CRITICAL!)
            relationships = []
            neighbor_importance = []
            
            for u, v, key, data in self.kg.out_edges(query_node, keys=True, data=True):
                rel_type = data.get('relationship', 'CONNECTED_TO')
                confidence = data.get('confidence')
                lift = data.get('lift')
                
                # Format relationship
                rel_str = f"  {u} --[{rel_type}]--> {v}"
                if confidence is not None:
                    rel_str += f" (confidence: {confidence:.2f})"
                if lift is not None:
                    rel_str += f" (lift: {lift:.2f})"
                
                relationships.append(rel_str)
                
                # Track neighbor importance
                importance = (lift or 1.0) * (confidence or 1.0)
                neighbor_importance.append((v, importance, rel_type))
            
            # Add relationship document
            if relationships:
                rel_doc = Document(
                    page_content=f"Graph relationships for {query_node}:\n" + "\n".join(relationships[:10]),
                    metadata={
                        "node_id": query_node,
                        "source": "graph_relationships",
                        "alpha": self.alpha,
                        "num_relationships": len(relationships)
                    }
                )
                all_docs.append(rel_doc)
                print(f"   ✓ Added {len(relationships)} relationships")
            
            # Add important neighbors
            neighbor_importance.sort(key=lambda x: x[1], reverse=True)
            
            for neighbor_id, importance, rel_type in neighbor_importance[:3]:
                if neighbor_id not in seen_nodes and neighbor_id in self.kg.nodes():
                    node_data = self.kg.nodes[neighbor_id]
                    neighbor_doc = Document(
                        page_content=self._generate_node_text(neighbor_id, node_data),
                        metadata={
                            "node_id": neighbor_id,
                            "node_type": node_data.get('node_type'),
                            "source": "graph_neighbor",
                            "relationship": rel_type,
                            "importance": importance
                        }
                    )
                    all_docs.append(neighbor_doc)
                    seen_nodes.add(neighbor_id)
        
        print(f"   ✓ Total documents: {len(all_docs)}")
        return all_docs[:15]
    



    async def _aget_relevant_documents(self, query: str) -> List[Document]:
        """Async version."""
        return self._get_relevant_documents(query)

    def get_relevant_documents(self, query: str) -> List[Document]:
        """Public method for compatibility."""
        return self._get_relevant_documents(query)
    

    def _find_matching_nodes(self, query: str) -> List[str]:
        """
        Find nodes that match the query string.
        
        Args:
            query: Search query (e.g., "Python", "backend")
            
        Returns:
            List of matching node IDs
        """
        query_lower = query.lower().strip()
        
        # Exact match
        if query in self.kg.nodes():
            return [query]
        
        # Partial match (case-insensitive)
        matches = []
        for node_id in self.node_ids:
            if query_lower in node_id.lower():
                matches.append(node_id)
        
        return matches



    def _find_similar_nodes(self, query_node_id: str, top_k: int = 5) -> List[Tuple[str, float]]:
        """
        Find most similar nodes using cosine similarity on weighted embeddings.
        
        This is where the embeddings are actually used!
        
        Args:
            query_node_id: Node to find similar nodes for
            top_k: Number of results to return
            
        Returns:
            List of (node_id, similarity_score) tuples, sorted by similarity
        """
        if query_node_id not in self.weighted_embeddings:
            return []
        
        query_emb = self.weighted_embeddings[query_node_id]
        similarities = []
        
        for node_id, node_emb in self.weighted_embeddings.items():
            # Skip self
            if node_id == query_node_id:
                continue
            
            # Calculate cosine similarity
            sim = cosine_similarity(
                query_emb.reshape(1, -1),
                node_emb.reshape(1, -1)
            )[0][0]
            
            similarities.append((node_id, float(sim)))
        
        # Sort by similarity (highest first)
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        return similarities[:top_k]
    
    def _generate_node_text(self, node_id: str, node_data: dict) -> str:
        """
        Generate human-readable text description for a node.
        
        Args:
            node_id: Node identifier
            node_data: Node attributes from graph
            
        Returns:
            Formatted description string
        """
        node_type = node_data.get('node_type', 'unknown')
        
        if node_type == 'Skill':
            text = f"Skill: {node_id}"
            
            if 'total_frequency' in node_data:
                text += f". Appears in {node_data['total_frequency']} job postings"
            
            if 'global_support' in node_data:
                percentage = node_data['global_support'] * 100
                text += f". Required by {percentage:.1f}% of positions"
        
        elif node_type == 'JobCategory':
            text = f"Job Role: {node_id}"
            
            if 'job_count' in node_data:
                text += f". {node_data['job_count']} positions analyzed"
            
            if 'avg_skills_required' in node_data:
                text += f". Typically requires {node_data['avg_skills_required']:.1f} skills"
        
        elif node_type == 'Skillset':
            skills = node_data.get('skills', [])
            if skills:
                text = f"Skill Combination: {' + '.join(skills)}"
            else:
                text = f"Skillset: {node_id}"
            
            if 'max_lift' in node_data:
                text += f". Lift score: {node_data['max_lift']:.2f}"
        
        else:
            text = f"{node_type}: {node_id}"
        
        return text

if __name__ == "__main__":
    print("✓ Retriever class with alpha weighting defined!")