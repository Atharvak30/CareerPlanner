# Career Skills GraphRAG System
Authors : Atharva Kulkarni , Siddhant Bhagay

A Graph Retrieval-Augmented Generation (GraphRAG) system for intelligent career guidance, powered by knowledge graphs and dual-layer embeddings.

## 🚀 Quick Start - Main Interface

**The main interface for this system is `graphRag.ipynb`** - this notebook provides the complete GraphRAG experience with natural language queries.

**Requirements:**
- **Gemini API Key** required to run the notebook
- Set your API key: `os.environ['GOOGLE_API_KEY'] = 'your-key-here'`
- Get a free API key at: https://aistudio.google.com/app/apikey

The notebook loads the pre-built knowledge graph and embeddings, and enables queries like:
- *"I want to be an ML engineer. I have Python and Java experience. What should my roadmap look like?"*
- *"What skills commonly appear with TensorFlow?"*

##  Data Collection & Pipeline

**All data collection infrastructure, Airflow jobs, and scraping pipelines are maintained in a separate repository:**

 **[CareerPlanner Repository](https://github.com/Atharvak30/CareerPlanner)**

 **Career Planner Presentation** https://docs.google.com/presentation/d/1S35Sn5162CIyyxOXWrhFYwkImHirUKBeKI8cX99aVis/edit?slide=id.g3ad78285e22_0_0#slide=id.g3ad78285e22_0_0

This repository contains:
- Automated job scraping infrastructure (Indeed scraper)
- Airflow DAGs for scheduled data collection
- Data preprocessing and cleaning pipelines
- Tech taxonomy and skill extraction tools

**For this project:** A pre-collected dataset (`job_dataset.csv`) is included in the `Data/` folder for reference and to enable immediate use of the GraphRAG system without running the full scraping pipeline.

##  Overview

This system scrapes job postings, extracts skill requirements, builds a knowledge graph of career relationships, and enables natural language queries about career paths, skill requirements, and job recommendations using a hybrid GraphRAG architecture.

##  System Architecture

```
Job Postings → Knowledge Graph → Dual Embeddings → Hybrid Retrieval → LLM-Powered Q&A
     ↓              ↓                  ↓                  ↓                  ↓
  Scraper    description_parser  embeddingGenerator  graphRetriever    graphRag
```

##  Components

### 1. **Job Scraper** (`CareerPlanner/IndeedJobScraper/`)
- **Purpose**: Collects real-world job postings from Indeed
- **Output**: Raw job descriptions stored in `Data/job_dataset.csv`
- **Features**:
  - Automated web scraping
  - Multiple job categories (Backend, Frontend, ML/AI, etc.)
  - Skill extraction from descriptions

### 2. **Description Parser** (`description_parser.ipynb`)
- **Purpose**: Transforms raw job descriptions into a structured knowledge graph
- **Input**: `Data/job_dataset.csv` (49 job postings)
- **Output**: `knowledge_graph/career_skills_kg_latest.pkl`

**Key Processes:**
- **Skill Extraction**: Identifies technical skills from job descriptions using pattern matching and NLP
- **Association Rule Mining**: Uses Apriori algorithm to discover:
  - Skill co-occurrence patterns (which skills appear together)
  - Skill prerequisites (learning paths)
  - Characteristic skillsets for job categories
- **Graph Construction**: Builds a NetworkX MultiDiGraph with:
  - **175 nodes**: 5 JobCategories, 62 Skills, 108 Skillsets
  - **1,558 edges**: REQUIRES, CO_OCCURS_WITH, LEADS_TO, CHARACTERISTIC_SKILLSET, PART_OF
  - **Rich metadata**: Confidence scores, lift values, support metrics

**Knowledge Graph Schema:**
```
Node Types:
  - JobCategory: Backend Engineer, Frontend Engineer, ML/AI Engineer, etc.
  - Skill: Python, Docker, React, SQL, etc.
  - Skillset: Combinations like "Docker + Kubernetes + Python"

Edge Types:
  - REQUIRES: JobCategory → Skill (confidence, lift)
  - CO_OCCURS_WITH: Skill ↔ Skill (co-occurrence patterns)
  - LEADS_TO: Skill → Skill (learning progressions)
  - CHARACTERISTIC_SKILLSET: JobCategory → Skillset (distinctive combinations)
  - PART_OF: Skill → Skillset (membership)
```

### 3. **Embedding Generator** (`embeddingGenerator.ipynb`)
- **Purpose**: Creates dual-layer vector representations for semantic + structural search
- **Input**: `knowledge_graph/career_skills_kg_latest.pkl`
- **Output**:
  - `knowledge_graph/text_embeddings.pkl` (175 × 384 matrix)
  - `knowledge_graph/graph_embeddings.pkl` (175 × 128 matrix)

**Two Embedding Layers:**

#### Layer 1: Text Embeddings (Semantic Layer)
- **Model**: SentenceTransformer `all-MiniLM-L6-v2`
- **Dimension**: 384
- **Purpose**: Captures semantic meaning of skills and jobs
- **How it works**:
  1. Generates rich text descriptions for each node (e.g., "Skill: Python. Appears in 18 job postings. Required by 36.7% of positions")
  2. Encodes text into dense vectors using pre-trained transformer
  3. Enables finding semantically similar concepts (e.g., "Python" ≈ "Java")

#### Layer 2: Graph Embeddings (Structural Layer)
- **Algorithm**: Node2Vec (random walk-based graph embedding)
- **Dimension**: 128
- **Purpose**: Captures structural patterns and relationship topology
- **How it works**:
  1. Performs random walks through the graph (walk_length=80, num_walks=10)
  2. Learns node representations that preserve neighborhood structure
  3. Captures skill co-occurrence and prerequisite patterns from graph topology
- **Why needed**: Text embeddings miss structural patterns like "Python + SQL commonly required together"

### 4. **Graph Retriever** (`graphRetriever.py`)
- **Purpose**: Hybrid retrieval system that combines semantic and structural similarity
- **Input**: Knowledge graph + both embedding types
- **Output**: Ranked list of relevant nodes and relationships for a query

**Key Features:**

#### Hybrid Weighting (Alpha Parameter)
```python
weighted_embedding = concatenate([(1-α)·text_emb, α·graph_emb])
```
- `α = 0.0`: Pure semantic search (text only)
- `α = 1.0`: Pure structural search (graph only)
- `α = 0.5`: Balanced hybrid
- `α = 0.6-0.8`: Recommended (favors structural patterns)

#### 4-Step Retrieval Process:
1. **Find Matching Nodes**: Exact/partial string match on query
2. **Similarity Search**: Cosine similarity on weighted embeddings (top-5 similar nodes)
3. **Graph Relationships**: Extract outgoing edges with confidence/lift scores
4. **Important Neighbors**: Add top-3 neighbors ranked by importance (lift × confidence)

**Example Query Flow:**
```
Query: "Python"
→ Match: Python (exact)
→ Similar: Java (0.766), TensorFlow (0.797), Shell (0.771)
→ Relationships: Python --[CO_OCCURS_WITH]--> Docker (lift: 2.5)
→ Neighbors: CI/CD, SQL, REST
→ Returns: 8-15 LangChain Document objects with metadata
```

### 5. **GraphRAG System** (`graphRag.ipynb`)
- **Purpose**: Main interface - combines retrieval + LLM for natural language Q&A
- **Input**: User's natural language query
- **Output**: Contextual answers powered by graph knowledge

**How it Works:**
1. **User Query**: "I want to be a Backend Engineer. What skills do I need?"
2. **Hybrid Retrieval**: graphRetriever finds relevant nodes (skills, jobs, relationships)
3. **Context Assembly**: Formats retrieved documents into context
4. **LLM Generation**: Passes context + query to OpenAI/Anthropic LLM
5. **Grounded Response**: LLM generates answer grounded in graph knowledge

**Key Features:**
- Natural language interface to knowledge graph
- Embedding-based semantic search (VectorStore class)
- Graph traversal for relationship exploration
- Career path recommendations
- Skill gap analysis
- Learning progression suggestions

## 🔧 Installation

```bash
# Clone repository
git clone <repo-url>
cd CareerScraper

# Install dependencies
pip install networkx sentence-transformers karateclub
pip install langchain langchain-core scikit-learn
pip install openai anthropic  # For LLM integration

# Optional: For job scraping
pip install selenium beautifulsoup4 pandas
```

## 📊 Data Flow

```
1. Job Scraping (IndeedJobScraper)
   └─> Data/job_dataset.csv (49 jobs)

2. Knowledge Graph Construction (description_parser.ipynb)
   └─> knowledge_graph/career_skills_kg_latest.pkl
       • 175 nodes (5 jobs, 62 skills, 108 skillsets)
       • 1,558 edges (REQUIRES, CO_OCCURS_WITH, LEADS_TO, etc.)

3. Embedding Generation (embeddingGenerator.ipynb)
   ├─> knowledge_graph/text_embeddings.pkl (175 × 384)
   └─> knowledge_graph/graph_embeddings.pkl (175 × 128)

4. Hybrid Retrieval (graphRetriever.py)
   └─> Combines embeddings with α weighting

5. GraphRAG Interface (graphRag.ipynb)
   └─> Natural language Q&A powered by LLM + retriever
```

## 🚀 Usage

### Quick Start

```python
# 1. Load the knowledge graph
import pickle
with open('knowledge_graph/career_skills_kg_latest.pkl', 'rb') as f:
    kg = pickle.load(f)

# 2. Load embeddings
with open('knowledge_graph/text_embeddings.pkl', 'rb') as f:
    text_data = pickle.load(f)
    text_embeddings = text_data['embeddings']
    node_ids = text_data['node_ids']

with open('knowledge_graph/graph_embeddings.pkl', 'rb') as f:
    graph_embeddings = pickle.load(f)

# 3. Initialize hybrid retriever
from graphRetriever import HybridGraphRetriever

retriever = HybridGraphRetriever(
    knowledge_graph=kg,
    node_ids=node_ids,
    text_embeddings=text_embeddings,
    graph_embeddings=graph_embeddings,
    alpha=0.7  # 70% graph, 30% text
)

# 4. Query the system
docs = retriever.get_relevant_documents("Python")

# 5. Use with LLM (see graphRag.ipynb for full implementation)
```

### Example Queries

```python
# Skill exploration
"What skills are similar to Python?"
"Which skills commonly appear with Docker?"

# Career guidance
"I want to be a Backend Engineer. What skills do I need?"
"What's the learning path from Python to machine learning?"

# Job recommendations
"I know Python, SQL, and Docker. What jobs am I qualified for?"
"What's missing in my skillset for ML/AI Engineer?"
```

## 📈 Knowledge Graph Statistics

- **Total Nodes**: 175
  - Job Categories: 5
  - Skills: 62
  - Skillsets: 108

- **Total Edges**: 1,558
  - REQUIRES: 158
  - CO_OCCURS_WITH: 224
  - LEADS_TO: 749
  - CHARACTERISTIC_SKILLSET: 108
  - PART_OF: 319

- **Data Source**: 49 real job postings from Indeed

##  Key Techniques

1. **Association Rule Mining**: Apriori algorithm to discover skill patterns
2. **Dual Embeddings**: Semantic (text) + structural (graph) representations
3. **Hybrid Retrieval**: Weighted fusion of embedding types with alpha parameter
4. **GraphRAG**: Combines graph retrieval with LLM generation for accurate, grounded answers
5. **Knowledge Graph**: NetworkX MultiDiGraph with rich metadata

##  File Structure

```
CareerScraper/
├── CareerPlanner/
│   ├── IndeedJobScraper/      # Web scraping tools
│   └── Data/                   # Raw job datasets
├── knowledge_graph/            # Generated artifacts
│   ├── career_skills_kg_latest.pkl      # Knowledge graph
│   ├── text_embeddings.pkl              # 175 × 384 embeddings
│   └── graph_embeddings.pkl             # 175 × 128 embeddings
├── description_parser.ipynb    # KG construction pipeline
├── embeddingGenerator.ipynb    # Dual embedding generation
├── graphRetriever.py           # HybridGraphRetriever class
├── graphRag.ipynb             # Main GraphRAG interface
└── KnowledgeGraph.txt         # Schema documentation
```



